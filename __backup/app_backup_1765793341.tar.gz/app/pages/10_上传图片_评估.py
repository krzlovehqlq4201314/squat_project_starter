import streamlit as st
from app.utils.i18n import t

st.title(t("upload_title"))
st.info(t("upload_tip"))

img = st.file_uploader(t("upload_prompt"), type=["jpg","jpeg","png"])
if img:
    st.success(t("upload_ok"))
    st.image(img)
