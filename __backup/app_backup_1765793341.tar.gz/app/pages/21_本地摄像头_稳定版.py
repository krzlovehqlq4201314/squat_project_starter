import streamlit as st
from app.utils.i18n import t

st.title(t("webcam_title"))
st.info(t("webcam_tip"))
# 你的摄像头/渲染/热力图逻辑放回这里（此处仅保留占位）
