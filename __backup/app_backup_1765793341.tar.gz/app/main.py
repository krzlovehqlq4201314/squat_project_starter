import streamlit as st
st.set_page_config(page_title="Squat Checker", layout="wide")

from app.utils.i18n import t, language_selector

with st.sidebar:
    language_selector(location="sidebar", key="lang_radio_global")

st.title(t("home_title"))
st.write(t("home_tip"))
