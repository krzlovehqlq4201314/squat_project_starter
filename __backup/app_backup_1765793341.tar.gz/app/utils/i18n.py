import streamlit as st

TRANSLATIONS = {
    "zh": {
        "app_name": "Squat Checker",
        "lang_label": "语言 / Language",
        "home_title": "首页 / Home",
        "home_tip": "在左侧选择上一页面，上传图像 或 本地摄像头（稳定版）。",
        "upload_title": "上传图片 评估",
        "upload_tip": "在此上传一张 JPG/PNG 照片（示例页面）。",
        "upload_prompt": "请选择一张 JPG/PNG",
        "upload_ok": "图片上传完成。",
        "webcam_title": "本地摄像头 · 稳定版",
        "webcam_tip": "此页面保留你自定义的摄像头识别/渲染逻辑入口。"
    },
    "en": {
        "app_name": "Squat Checker",
        "lang_label": "Language",
        "home_title": "Home",
        "home_tip": "Use the sidebar to switch pages: Upload Image or Webcam (stable).",
        "upload_title": "Upload & Evaluate",
        "upload_tip": "Upload a JPG/PNG image here (demo).",
        "upload_prompt": "Choose a JPG/PNG",
        "upload_ok": "Image uploaded.",
        "webcam_title": "Webcam · Stable",
        "webcam_tip": "Put your webcam capture/inference/rendering loop here."
    },
    "ko": {
        "app_name": "스쿼트 체커",
        "lang_label": "언어",
        "home_title": "홈",
        "home_tip": "왼쪽에서 페이지를 선택하세요: 이미지 업로드 / 웹캠(안정판).",
        "upload_title": "이미지 업로드 · 평가",
        "upload_tip": "여기에 JPG/PNG 이미지를 업로드하세요(데모).",
        "upload_prompt": "JPG/PNG 파일을 선택하세요",
        "upload_ok": "이미지 업로드 완료.",
        "webcam_title": "로컬 웹캠 · 안정판",
        "webcam_tip": "여기에 웹캠 캡처/추론/표시 루프를 넣어주세요."
    }
}
LANGS = {"zh":"中文","en":"English","ko":"한국어"}

def t(key: str) -> str:
    lang = st.session_state.get("lang","zh")
    return TRANSLATIONS.get(lang, {}).get(key, key)

def language_selector(location="sidebar", key="lang_radio_global"):
    container = st.sidebar if location=="sidebar" else st
    current = st.session_state.get("lang","zh")
    order = ["zh","en","ko"]
    idx = order.index(current) if current in order else 0
    choice = container.radio(
        t("lang_label"),
        order,
        index=idx,
        format_func=lambda c: LANGS[c],
        key=key
    )
    st.session_state["lang"] = choice
    return choice
