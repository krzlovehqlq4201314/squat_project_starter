import streamlit as st
st.set_page_config(page_title="Squat Checker", layout="wide")  # 必须第一行的 Streamlit 调用

# ---- 解决 import 路径混乱（避免 "app 不是包"）----
import os, sys
# 把 app 根目录放到 sys.path 前面
_here = os.path.abspath(__file__)
_app_dir = os.path.dirname(_here)                # 默认：app/app.py 时 -> app
if os.path.basename(os.path.dirname(_here)) == "pages":
    _app_dir = os.path.dirname(os.path.dirname(_here))  # app/pages/*.py 时 -> app
if _app_dir not in sys.path:
    sys.path.insert(0, _app_dir)

from utils.i18n import t, init_language, language_selector
init_language()
language_selector(location="sidebar", key="lang_radio_webcam")

import streamlit as st
# [patched] removed duplicate set_page_config  # 各页面第一行

# [patched] import via utils.i18n

st.title(t("webcam_title"))
st.caption(t("webcam_tip"))

st.info("📌 占位页面：此处接入你的本地摄像头深蹲识别逻辑。\n\n"
        "如果你使用 OpenCV：请先安装 `pip install opencv-python`，并在此处编写读取/推理/展示的循环。")
# TODO: 在这里粘贴你原本“第三个能识别深蹲”的摄像头推理代码
