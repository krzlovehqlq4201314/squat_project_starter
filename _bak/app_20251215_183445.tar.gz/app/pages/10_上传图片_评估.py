import streamlit as st
st.set_page_config(page_title="Squat Checker", layout="wide")  # 必须第一行的 Streamlit 调用

# ---- 解决 import 路径混乱（避免 "app 不是包"）----
import os, sys
# 把 app 根目录放到 sys.path 前面
_here = os.path.abspath(__file__)
_app_dir = os.path.dirname(_here)                # 默认：app/app.py 时 -> app
if os.path.basename(os.path.dirname(_here)) == "pages":
    _app_dir = os.path.dirname(os.path.dirname(_here))  # app/pages/*.py 时 -> app
if _app_dir not in sys.path:
    sys.path.insert(0, _app_dir)

from utils.i18n import t, init_language, language_selector
init_language()
language_selector(location="sidebar", key="lang_radio_upload")

import streamlit as st
# [patched] removed duplicate set_page_config  # 各页面第一行

# [patched] import via utils.i18n
from PIL import Image

st.title(t("upload_title"))
st.caption(t("upload_tip"))

uploaded = st.file_uploader(t("upload_prompt"), type=["jpg","jpeg","png"])
if uploaded is not None:
    img = Image.open(uploaded).convert("RGB")
    st.success(t("upload_ok"))
    st.image(img, use_column_width=True)

# ---- 这里是你原先的角度/热力图/关键点逻辑的插槽 ----
# TODO: 把你之前的推理/可视化代码粘到这里（读取 img 变量即可）
