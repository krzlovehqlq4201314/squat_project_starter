# coding: utf-8
import streamlit as st

# --- 简单的翻译字典（可自行补充） ---
TRANSLATIONS = {
    "zh": {
        "app_name": "Squat Checker",
        "lang_label": "语言 / Language",
        "home_title": "首页 / Home",
        "home_tip": "在左侧选择：上传图片 评估 或 本地摄像头 稳定版。",
        "upload_title": "上传图片 · 评估",
        "upload_prompt": "请上传一张 JPG/PNG",
        "upload_ok": "图片上传并展示在下方。",
        "webcam_title": "本地摄像头 · 稳定版",
    },
    "en": {
        "app_name": "Squat Checker",
        "lang_label": "Language",
        "home_title": "Home",
        "home_tip": "Choose page at left: Image Upload or Webcam.",
        "upload_title": "Upload & Evaluate",
        "upload_prompt": "Please upload a JPG/PNG",
        "upload_ok": "Image uploaded and shown below.",
        "webcam_title": "Webcam (stable)",
    },
    "ko": {
        "app_name": "Squat Checker",
        "lang_label": "언어",
        "home_title": "홈",
        "home_tip": "왼쪽에서 페이지를 선택하세요: 이미지 업로드 / 웹캠.",
        "upload_title": "이미지 업로드 · 평가",
        "upload_prompt": "JPG/PNG 이미지를 업로드 하세요",
        "upload_ok": "이미지가 아래에 표시됩니다.",
        "webcam_title": "웹캠 (안정판)",
    },
}

_LANG_LABELS = {"zh": "中文", "en": "English", "ko": "한국어"}
_LANG_LIST   = ["zh", "en", "ko"]

def init_language(default: str = "zh") -> None:
    """仅初始化 session_state['lang']，不渲染任何 UI。"""
    if "lang" not in st.session_state:
        st.session_state["lang"] = default

def language_selector(location: str = "sidebar", key: str = "lang_radio"):
    """在 sidebar 或主区渲染语言选择，不在导入时调用。"""
    container = st.sidebar if location == "sidebar" else st
    current   = st.session_state.get("lang", "zh")
    idx       = _LANG_LIST.index(current) if current in _LANG_LIST else 0
    choice = container.radio(
        TRANSLATIONS[current]["lang_label"] if current in TRANSLATIONS else "Language",
        _LANG_LIST,
        index=idx,
        key=key,
        format_func=lambda x: _LANG_LABELS.get(x, x),
    )
    st.session_state["lang"] = choice
    return choice

def t(key: str, **kwargs) -> str:
    """按当前语言取文案；没有就回退 key 本身。"""
    lang = st.session_state.get("lang", "zh")
    text = TRANSLATIONS.get(lang, {}).get(key, key)
    try:
        return text.format(**kwargs)
    except Exception:
        return text
