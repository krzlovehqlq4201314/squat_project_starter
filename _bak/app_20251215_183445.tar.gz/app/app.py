import streamlit as st
st.set_page_config(page_title="Squat Checker", layout="wide")  # 必须第一行的 Streamlit 调用

# ---- 解决 import 路径混乱（避免 "app 不是包"）----
import os, sys
# 把 app 根目录放到 sys.path 前面
_here = os.path.abspath(__file__)
_app_dir = os.path.dirname(_here)                # 默认：app/app.py 时 -> app
if os.path.basename(os.path.dirname(_here)) == "pages":
    _app_dir = os.path.dirname(os.path.dirname(_here))  # app/pages/*.py 时 -> app
if _app_dir not in sys.path:
    sys.path.insert(0, _app_dir)

from utils.i18n import t, init_language, language_selector
init_language()
language_selector(location="sidebar", key="lang_radio_global")

import streamlit as st
# [patched] removed duplicate set_page_config  # 必须第一行
# [patched] import via utils.i18n
language_selector(location="sidebar", key="lang_radio_global")

# [patched] import via utils.i18n

# 全局语言切换（只在 app.py 调用一次）
language_selector(place="sidebar", key="lang_radio_global")

st.title(t("home_title"))
st.caption(t("home_tip"))
